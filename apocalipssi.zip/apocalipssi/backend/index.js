require("dotenv").config()
const express = require("express")
const mongoose = require("mongoose")
const connectDB = require("./models/connection")

const app = express()
app.use(express.json())
const cors = require("cors")
app.use(cors())
connectDB()

const conn = mongoose.connection
conn.once("open", () => {
  const GridFSBucket = new mongoose.mongo.GridFSBucket(conn.db, {
    bucketName: "documents",
  })
  app.locals.gfs = GridFSBucket
  console.log("🟢 GridFSBucket initialisé")
})

const documentsRoute = require("./routes/documentsRoute")
app.use("/documents", documentsRoute)

app.get("/", (req, res) => res.send("API en ligne 🚀"))

const PORT = process.env.PORT || 5000
app.listen(PORT, () => console.log(`🚀 Serveur lancé sur le port ${PORT}`))
